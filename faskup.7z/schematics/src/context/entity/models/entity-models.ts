import { ModelContext } from "./model";
import { EntityBehaviors } from "../entity-behaviors";

export class EntityModelsContext {
    public read: ModelContext;
    public create: ModelContext;
    public update: ModelContext;
    public delete: ModelContext;
    constructor(entityName: string, rootPath: string) {
        this.read = new ModelContext(entityName, EntityBehaviors.Read, rootPath);
        this.create = new ModelContext(entityName, EntityBehaviors.Create, rootPath);
        this.update = new ModelContext(entityName, EntityBehaviors.Update, rootPath);
        this.delete = new ModelContext(entityName, EntityBehaviors.Delete, rootPath);
    }
}
