import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { EntityBehaviors } from "../entity-behaviors";

export class ModelContext {
    constructor(private entityName: string, private behavior: EntityBehaviors, private packagePath: string) {
    }
    get typeName(): string {
        return classify(`${this.entityName}${this.behavior}Model`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}${this.behavior}`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/models/${this.fileName}`);
    }
}
