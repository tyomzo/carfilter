import { dasherize, camelize } from "@angular-devkit/core/src/utils/strings";
import { BehaviorReducerContext } from "./behavior-reducer";
import { EntityActionsContext } from "../actions/entity-actions";
import { EntityBehaviors } from "../../entity-behaviors";

export class EntityReducerContext {
    public read: BehaviorReducerContext;
    public create: BehaviorReducerContext;
    public update: BehaviorReducerContext;
    public delete: BehaviorReducerContext;
    constructor(public entityName: string, public rootPath: string, actions: EntityActionsContext) {
        this.read = new BehaviorReducerContext(entityName, EntityBehaviors.Read, rootPath, actions.read);
        this.create = new BehaviorReducerContext(entityName, EntityBehaviors.Create, rootPath, actions.create);
        this.update = new BehaviorReducerContext(entityName, EntityBehaviors.Update, rootPath, actions.update);
        this.delete = new BehaviorReducerContext(entityName, EntityBehaviors.Delete, rootPath, actions.delete);
    }
    get reducerName(): string {
        return camelize(`${this.entityName}Reducer`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.reducer`);
    }
    get importPath(): string {
        return dasherize(`${this.rootPath}/${this.entityName}/state/reducers/${this.fileName}`);
    }
    get initialState(): string {
        return 'initialState';
    }
}
