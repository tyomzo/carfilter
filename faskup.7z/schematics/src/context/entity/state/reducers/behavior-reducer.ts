import { dasherize, camelize } from "@angular-devkit/core/src/utils/strings";
import { BehaviorActionsContext } from "../actions/behavior-action";
import { EntityBehaviors } from "../../entity-behaviors";

export class BehaviorReducerContext {
    constructor(private entityName: string, public behavior: EntityBehaviors, private packagePath: string, public actions: BehaviorActionsContext) {
    }
    get reducerName(): string {
        return camelize(`${this.entityName}${this.behavior}Reducer`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}${this.behavior}.reducer`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/state/reducers/${this.fileName}`);
    }
}
