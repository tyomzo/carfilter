import { BehaviorActionsContext } from "./behavior-action";
import { EntityModelsContext } from "../../models/entity-models";
import { EntityBehaviors } from "../../entity-behaviors";
export class EntityActionsContext {
    public read: BehaviorActionsContext;
    public create: BehaviorActionsContext;
    public update: BehaviorActionsContext;
    public delete: BehaviorActionsContext;
    constructor(entityName: string, rootPath: string, models: EntityModelsContext) {
        this.read = new BehaviorActionsContext(entityName, EntityBehaviors.Read, rootPath, models.read);
        this.create = new BehaviorActionsContext(entityName, EntityBehaviors.Create, rootPath, models.create);
        this.update = new BehaviorActionsContext(entityName, EntityBehaviors.Update, rootPath, models.update);
        this.delete = new BehaviorActionsContext(entityName, EntityBehaviors.Delete, rootPath, models.delete);
    }
}
