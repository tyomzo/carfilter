import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { ModelContext } from "../../models/model";
import { EntityBehaviors } from "../../entity-behaviors";

export class BehaviorActionsContext {
    constructor(private entityName: string, public behavior: EntityBehaviors, private packagePath: string, public model: ModelContext) {
    }
    get actionTypes(): string {
        return classify(`${this.entityName}${this.behavior}ActionTypes`);
    }
    get actionsRoute(): string {
        return dasherize(`${this.packagePath}/${this.entityName}${this.behavior}`);
    }
    get typeName(): string {
        return classify(`${this.entityName}${this.behavior}Actions`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}${this.behavior}.actions`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/state/actions/${this.fileName}`);
    }
}
