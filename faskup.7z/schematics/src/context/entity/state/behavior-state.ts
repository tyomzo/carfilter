import { classify, dasherize, camelize } from "@angular-devkit/core/src/utils/strings";
import { ModelContext } from "../models/model";
import { EntityBehaviors } from "../entity-behaviors";

export class BehaviorStateContext {
    constructor(public entityName: string, public behavior: EntityBehaviors, public packagePath: string, public model: ModelContext) {
    }
    get selector(): string {
        return camelize((`${this.entityName}${this.behavior}Selector`));
    }
    get typeName(): string {
        return classify(`${this.entityName}${this.behavior}State`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.state`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/state/${this.fileName}`);
    }
}
