import { classify, dasherize, camelize } from "@angular-devkit/core/src/utils/strings";
import { BehaviorStateContext } from "./behavior-state";
import { EntityModelsContext } from "../models/entity-models";
import { EntityBehaviors } from "../entity-behaviors";

export class AggregatedStateContext {
    public read: BehaviorStateContext;
    public create: BehaviorStateContext;
    public update: BehaviorStateContext;
    public delete: BehaviorStateContext;
    constructor(public entityName: string, public rootPath: string, models: EntityModelsContext) {
        this.read = new BehaviorStateContext(entityName, EntityBehaviors.Read, rootPath, models.read);
        this.create = new BehaviorStateContext(entityName, EntityBehaviors.Create, rootPath, models.create);
        this.update = new BehaviorStateContext(entityName, EntityBehaviors.Update, rootPath, models.update);
        this.delete = new BehaviorStateContext(entityName, EntityBehaviors.Delete, rootPath, models.delete);
    }
    get typeName(): string {
        return classify(`${this.entityName}State`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.state`);
    }
    get importPath(): string {
        return dasherize(`${this.rootPath}/${this.entityName}/state/${this.fileName}`);
    }
    get selector(): string {
        return camelize((`${this.entityName}Selector`));
    }
    get stateName(): string {
        return classify(this.entityName);
    }
}
