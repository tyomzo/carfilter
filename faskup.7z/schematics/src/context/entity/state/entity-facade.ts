import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { EntityModelsContext } from "../models/entity-models";
import { EntityActionsContext } from "./actions/entity-actions";

export class EntityFacadeContext {
    constructor(private entityName: string, private packagePath: string, public models: EntityModelsContext, public actions: EntityActionsContext) {
    }
    get typeName(): string {
        return classify(`${this.entityName}Facade`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.facade`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/state/${this.fileName}`);
    }
}
