import { classify, camelize } from "@angular-devkit/core/src/utils/strings";
import { ClientContext } from "../../client/client";
import { ServiceContext } from "../services/service";
import { AggregatedStateContext } from "./aggregated-state";
import { EntityEffectsContext } from "./effects/entity-effects";
import { EntityReducerContext } from "./reducers/entity-reducer";
import { EntityFacadeContext } from "./entity-facade";
import { EntityModelsContext } from "../models/entity-models";
import { EntityActionsContext } from "./actions/entity-actions";

export class EntityStateContext {
    constructor(private entityName: string, public rootPath: string, public parentAnchor: string, public client: ClientContext, public models: EntityModelsContext, public service: ServiceContext, public actions: EntityActionsContext, public state: AggregatedStateContext, public reducer: EntityReducerContext, public effects: EntityEffectsContext, public facade: EntityFacadeContext) {
        this.parentAnchor = camelize(entityName);
    }
    get name(): string {
        return classify(this.entityName);
    }
}
