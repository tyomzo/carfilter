import { ModelContext } from "../models/model";
import { BehaviorStateContext } from "./behavior-state";
import { BehaviorEffectsContext } from "./effects/behavior-effects";
import { BehaviorReducerContext } from "./reducers/behavior-reducer";
import { BehaviorActionsContext } from "./actions/behavior-action";
import { EntityFacadeContext } from "./entity-facade";
import { EntityBehaviors } from "../entity-behaviors";

export class EntityWriteStateContext {
    constructor(public model: ModelContext, public behavior: EntityBehaviors, public facade: EntityFacadeContext, public parentState: BehaviorStateContext, public actions: BehaviorActionsContext, public reducer: BehaviorReducerContext, public effects: BehaviorEffectsContext) { }
}
