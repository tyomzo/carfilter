import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { ServiceContext } from "../../services/service";
import { BehaviorActionsContext } from "../actions/behavior-action";
import { EntityBehaviors } from "../../entity-behaviors";

export class BehaviorEffectsContext {
    constructor(private entityName: string, public behavior: EntityBehaviors, private packagePath: string, public actions: BehaviorActionsContext, public service: ServiceContext) {
    }
    get typeName(): string {
        return classify(`${this.entityName}${this.behavior}Effects`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}${this.behavior}.effects`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/state/effects/${this.fileName}`);
    }
}
