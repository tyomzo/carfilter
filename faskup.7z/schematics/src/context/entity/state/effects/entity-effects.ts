import { ServiceContext } from "../../services/service";
import { BehaviorEffectsContext } from "./behavior-effects";
import { EntityActionsContext } from "../actions/entity-actions";
import { EntityBehaviors } from "../../entity-behaviors";

export class EntityEffectsContext {
    public read: BehaviorEffectsContext;
    public create: BehaviorEffectsContext;
    public update: BehaviorEffectsContext;
    public delete: BehaviorEffectsContext;
    constructor(entityName: string, rootPath: string, actions: EntityActionsContext, service: ServiceContext) {
        this.read = new BehaviorEffectsContext(entityName, EntityBehaviors.Read, rootPath, actions.read, service);
        this.create = new BehaviorEffectsContext(entityName, EntityBehaviors.Create, rootPath, actions.create, service);
        this.update = new BehaviorEffectsContext(entityName, EntityBehaviors.Update, rootPath, actions.update, service);
        this.delete = new BehaviorEffectsContext(entityName, EntityBehaviors.Delete, rootPath, actions.delete, service);
    }
}
