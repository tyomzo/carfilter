import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { ClientContext } from "../client/client";
import { ServiceContext } from "./services/service";
import { EntityStateContext } from "./state/entity-state";
import { entityStateContextFactory } from "./entityStateContextFactory";
import { EntityModelsContext } from "./models/entity-models";
import { EntityComponentsContext } from "./components/entity-component";

export class EntityContext {
    constructor(public entityName: string, public packagePath: string, parentAnchor: string) {
        this.rootPath = dasherize(this.packagePath);
        this.models = new EntityModelsContext(entityName, this.rootPath);
        this.client = new ClientContext(entityName, dasherize(this.packagePath));
        this.service = new ServiceContext(entityName, this.rootPath, this.models, this.client);
        this.state = entityStateContextFactory(entityName, packagePath, parentAnchor);
        this.component = new EntityComponentsContext(entityName, packagePath, this.state);
    }
    public rootPath: string;
    public service: ServiceContext;
    public models: EntityModelsContext;
    public client: ClientContext;
    public state: EntityStateContext;
    public component: EntityComponentsContext;
    
    get typeName(): string {
        return classify(`${this.entityName}Module`);
    }
    
    get fileName(): string {
        return dasherize(`${this.entityName}.module`);
    }
    
    get importPath(): string {
        return dasherize(`${this.rootPath}/${this.fileName}`);
    }
}
