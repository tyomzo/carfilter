import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { ClientContext } from "../../client/client";
import { EntityModelsContext } from "../models/entity-models";
export class ServiceContext {
    constructor(private entityName: string, private packagePath: string, public models: EntityModelsContext, public client: ClientContext) {
    }
    get typeName(): string {
        return classify(`${this.entityName}Service`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.service`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/services/${this.fileName}`);
    }
}
