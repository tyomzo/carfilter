export enum EntityBehaviors {
    Read = "Read",
    Create = "Create",
    Update = "Update",
    Delete = "Delete"
}
