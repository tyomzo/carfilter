import { ClientContext } from "../client/client";
import { ServiceContext } from "./services/service";
import { AggregatedStateContext } from "./state/aggregated-state";
import { EntityEffectsContext } from "./state/effects/entity-effects";
import { EntityReducerContext } from "./state/reducers/entity-reducer";
import { EntityFacadeContext } from "./state/entity-facade";
import { EntityStateContext } from "./state/entity-state";
import { EntityModelsContext } from "./models/entity-models";
import { EntityActionsContext } from "./state/actions/entity-actions";

export function entityStateContextFactory(entityName: string, rootPath: string, parentAnchor: string): EntityStateContext {
    const client = new ClientContext(entityName, rootPath);
    const models = new EntityModelsContext(entityName, rootPath);
    const service = new ServiceContext(entityName, rootPath, models, client);
    const actions = new EntityActionsContext(entityName, rootPath, models);
    const facade = new EntityFacadeContext(entityName, rootPath, models, actions);
    const state = new AggregatedStateContext(entityName, rootPath, models);
    const reducer = new EntityReducerContext(entityName, rootPath, actions);
    const effects = new EntityEffectsContext(entityName, rootPath, actions, service);
    return new EntityStateContext(entityName, rootPath, parentAnchor, client, models, service, actions, state, reducer, effects, facade);
}
