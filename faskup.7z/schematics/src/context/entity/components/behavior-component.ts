import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
import { BehaviorStateContext } from "../state/behavior-state";
import { EntityBehaviors } from "../entity-behaviors";

export class BehaviorComponentContext {
    constructor(private entityName: string, public behavior: EntityBehaviors, private packagePath: string, public state: BehaviorStateContext) { }
    get typeName(): string {
        return classify(`${this.entityName}${this.behavior}Component`);
    }
    get selector(): string {
        return dasherize(`st-${this.entityName}-${this.behavior}`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}${this.behavior}.component`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/${this.entityName}/components/${this.behavior}/${this.fileName}`);
    }
}
