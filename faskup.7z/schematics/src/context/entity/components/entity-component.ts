import { BehaviorComponentContext } from "./behavior-component";
import { EntityStateContext } from "../state/entity-state";
import { EntityBehaviors } from "../entity-behaviors";
import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";

export class EntityComponentsContext {
    constructor(public entityName: string, public rootPath: string, public state: EntityStateContext) {
        this.read = new BehaviorComponentContext(entityName, EntityBehaviors.Read, rootPath, state.state.read);
        this.create = new BehaviorComponentContext(entityName, EntityBehaviors.Create, rootPath, state.state.create);
        this.update = new BehaviorComponentContext(entityName, EntityBehaviors.Update, rootPath, state.state.update);
        this.delete = new BehaviorComponentContext(entityName, EntityBehaviors.Delete, rootPath, state.state.delete);
    }
    public read: BehaviorComponentContext;
    public create: BehaviorComponentContext;
    public update: BehaviorComponentContext;
    public delete: BehaviorComponentContext;

    get typeName(): string {
        return classify(`${this.entityName}Component`);
    }
    get selector(): string {
        return dasherize(`st-${this.entityName}`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.component`);
    }
    get importPath(): string {
        return dasherize(`${this.rootPath}/${this.entityName}/components/${this.fileName}`);
    }
}
