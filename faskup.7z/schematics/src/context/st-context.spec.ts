import { entityStateContextFactory } from './entity/entityStateContextFactory';

describe('st-context', () => {
    describe('entityStateContextFactory', () => {
        it('creates context', () => {
            const context = createContext();
            expect(!!context).toBeTruthy();
        });

        describe('Client', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.client).toBeTruthy();
            });

            it('type name is valid', () => {
                const context = createContext();
                expect(context.client.typeName).toBe('TestClient'); 
            });

            it('file name is valid', () => {
                const context = createContext();
                expect(context.client.fileName).toBe('test.client'); 
            });

            it('import path is valid', () => {
                const context = createContext();
                expect(context.client.importPath).toBe('@st/schematics/clients/test.client'); 
            });
        });

        describe('Models', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.models).toBeTruthy();
            });

            describe('Read Model', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.models.read.typeName).toBe('TestReadModel'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.models.read.fileName).toBe('test-read'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.models.read.importPath).toBe('@st/schematics/test/models/test-read'); 
                });
            });

            describe('Create Model', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.models.create.typeName).toBe('TestCreateModel'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.models.create.fileName).toBe('test-create'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.models.create.importPath).toBe('@st/schematics/test/models/test-create'); 
                });
            });

            describe('Update Model', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.models.update.typeName).toBe('TestUpdateModel'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.models.update.fileName).toBe('test-update'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.models.update.importPath).toBe('@st/schematics/test/models/test-update'); 
                });
            });

            describe('Delete Model', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.models.delete.typeName).toBe('TestDeleteModel'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.models.delete.fileName).toBe('test-delete'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.models.delete.importPath).toBe('@st/schematics/test/models/test-delete'); 
                });
            });
        });

        describe('Service', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.service).toBeTruthy();
            });

            it('type name is valid', () => {
                const context = createContext();
                expect(context.service.typeName).toBe('TestService'); 
            });

            it('file name is valid', () => {
                const context = createContext();
                expect(context.service.fileName).toBe('test.service'); 
            });

            it('import path is valid', () => {
                const context = createContext();
                expect(context.service.importPath).toBe('@st/schematics/test/services/test.service'); 
            });
        });

        describe('Actions', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.actions).toBeTruthy();
            });

            describe('Read Actions', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.actions.read.typeName).toBe('TestReadActions'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.actions.read.fileName).toBe('test-read.actions'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.actions.read.importPath).toBe('@st/schematics/test/state/actions/test-read.actions'); 
                });

                it('actionsRoute is valid', () => {
                    const context = createContext();
                    expect(context.actions.read.actionsRoute).toBe('@st/schematics/test-read'); 
                });

                it('actionTypes is valid', () => {
                    const context = createContext();
                    expect(context.actions.read.actionTypes).toBe('TestReadActionTypes'); 
                });
            });

            describe('Create Actions', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.actions.create.typeName).toBe('TestCreateActions'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.actions.create.fileName).toBe('test-create.actions'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.actions.create.importPath).toBe('@st/schematics/test/state/actions/test-create.actions'); 
                });

                it('actionsRoute is valid', () => {
                    const context = createContext();
                    expect(context.actions.create.actionsRoute).toBe('@st/schematics/test-create'); 
                });

                it('actionTypes is valid', () => {
                    const context = createContext();
                    expect(context.actions.create.actionTypes).toBe('TestCreateActionTypes'); 
                });
            });

            describe('Update Actions', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.actions.update.typeName).toBe('TestUpdateActions'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.actions.update.fileName).toBe('test-update.actions'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.actions.update.importPath).toBe('@st/schematics/test/state/actions/test-update.actions'); 
                });

                it('actionsRoute is valid', () => {
                    const context = createContext();
                    expect(context.actions.update.actionsRoute).toBe('@st/schematics/test-update'); 
                });

                it('actionTypes is valid', () => {
                    const context = createContext();
                    expect(context.actions.update.actionTypes).toBe('TestUpdateActionTypes'); 
                });
            });

            describe('Delete Actions', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.actions.delete.typeName).toBe('TestDeleteActions'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.actions.delete.fileName).toBe('test-delete.actions'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.actions.delete.importPath).toBe('@st/schematics/test/state/actions/test-delete.actions'); 
                });

                it('actionsRoute is valid', () => {
                    const context = createContext();
                    expect(context.actions.delete.actionsRoute).toBe('@st/schematics/test-delete'); 
                });

                it('actionTypes is valid', () => {
                    const context = createContext();
                    expect(context.actions.delete.actionTypes).toBe('TestDeleteActionTypes'); 
                });
            });
        });

        describe('Reducers', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.reducer).toBeTruthy();
            });

            it('type name is valid', () => {
                const context = createContext();
                expect(context.reducer.reducerName).toBe('testReducer'); 
            });

            it('file name is valid', () => {
                const context = createContext();
                expect(context.reducer.fileName).toBe('test.reducer'); 
            });

            it('import path is valid', () => {
                const context = createContext();
                expect(context.reducer.importPath).toBe('@st/schematics/test/state/reducers/test.reducer'); 
            });

            describe('Read Reducer', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.read.reducerName).toBe('testReadReducer'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.read.fileName).toBe('test-read.reducer'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.reducer.read.importPath).toBe('@st/schematics/test/state/reducers/test-read.reducer'); 
                });
            });

            describe('Create Reducer', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.create.reducerName).toBe('testCreateReducer'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.create.fileName).toBe('test-create.reducer'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.reducer.create.importPath).toBe('@st/schematics/test/state/reducers/test-create.reducer'); 
                });
            });

            describe('Update Reducer', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.update.reducerName).toBe('testUpdateReducer'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.update.fileName).toBe('test-update.reducer'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.reducer.update.importPath).toBe('@st/schematics/test/state/reducers/test-update.reducer'); 
                });
            });

            describe('Delete Reducer', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.delete.reducerName).toBe('testDeleteReducer'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.reducer.delete.fileName).toBe('test-delete.reducer'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.reducer.delete.importPath).toBe('@st/schematics/test/state/reducers/test-delete.reducer'); 
                });
            });
        });

        describe('Effects', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.effects).toBeTruthy();
            });

            describe('Read Effects', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.effects.read.typeName).toBe('TestReadEffects'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.effects.read.fileName).toBe('test-read.effects'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.effects.read.importPath).toBe('@st/schematics/test/state/effects/test-read.effects'); 
                });
            });

            describe('Create Effects', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.effects.create.typeName).toBe('TestCreateEffects'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.effects.create.fileName).toBe('test-create.effects'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.effects.create.importPath).toBe('@st/schematics/test/state/effects/test-create.effects'); 
                });
            });

            describe('Update Effects', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.effects.update.typeName).toBe('TestUpdateEffects'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.effects.update.fileName).toBe('test-update.effects'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.effects.update.importPath).toBe('@st/schematics/test/state/effects/test-update.effects'); 
                });
            });

            describe('Delete Effects', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.effects.delete.typeName).toBe('TestDeleteEffects'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.effects.delete.fileName).toBe('test-delete.effects'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.effects.delete.importPath).toBe('@st/schematics/test/state/effects/test-delete.effects'); 
                });
            });
        });

        describe('State', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.state).toBeTruthy();
            });

            it('type name is valid', () => {
                const context = createContext();
                expect(context.state.typeName).toBe('TestState'); 
            });

            it('file name is valid', () => {
                const context = createContext();
                expect(context.state.fileName).toBe('test.state'); 
            });

            it('import path is valid', () => {
                const context = createContext();
                expect(context.state.importPath).toBe('@st/schematics/test/state/test.state'); 
            });

            describe('Read State', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.state.read.typeName).toBe('TestReadState'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.state.read.fileName).toBe('test.state'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.state.read.importPath).toBe('@st/schematics/test/state/test.state'); 
                });
            });

            describe('Create State', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.state.create.typeName).toBe('TestCreateState'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.state.create.fileName).toBe('test.state'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.state.create.importPath).toBe('@st/schematics/test/state/test.state'); 
                });
            });

            describe('Update State', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.state.update.typeName).toBe('TestUpdateState'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.state.update.fileName).toBe('test.state'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.state.update.importPath).toBe('@st/schematics/test/state/test.state'); 
                });
            });

            describe('Delete State', () => {
                it('type name is valid', () => {
                    const context = createContext();
                    expect(context.state.delete.typeName).toBe('TestDeleteState'); 
                });
    
                it('file name is valid', () => {
                    const context = createContext();
                    expect(context.state.delete.fileName).toBe('test.state'); 
                });
    
                it('import path is valid', () => {
                    const context = createContext();
                    expect(context.state.delete.importPath).toBe('@st/schematics/test/state/test.state'); 
                });
            });
        });

        describe('Facade', () => {
            it('created', () => {
                const context = createContext();
                expect(!!context.facade).toBeTruthy();
            });

            it('type name is valid', () => {
                const context = createContext();
                expect(context.facade.typeName).toBe('TestFacade'); 
            });

            it('file name is valid', () => {
                const context = createContext();
                expect(context.facade.fileName).toBe('test.facade'); 
            });

            it('import path is valid', () => {
                const context = createContext();
                expect(context.facade.importPath).toBe('@st/schematics/test/state/test.facade'); 
            });
        });
    });

    function createContext() {
        return entityStateContextFactory('test', '@st/schematics', 'test');
    }
});
