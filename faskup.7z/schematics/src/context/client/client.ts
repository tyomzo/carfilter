import { classify, dasherize } from "@angular-devkit/core/src/utils/strings";
export class ClientContext {
    constructor(private entityName: string, private packagePath: string) {
    }
    get typeName(): string {
        return classify(`${this.entityName}Client`);
    }
    get fileName(): string {
        return dasherize(`${this.entityName}.client`);
    }
    get importPath(): string {
        return dasherize(`${this.packagePath}/clients/${this.fileName}`);
    }
}
