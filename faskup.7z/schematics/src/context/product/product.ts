import { dasherize, camelize } from "@angular-devkit/core/src/utils/strings";

export class ProductContext {
    constructor(private _packageName: string, public path: string) { }

    public get packageName () {
        return dasherize(`@st/${this._packageName}`);
    }

    public get prefix() {
        return 'st-';
    }

    public get entryFile () {
        return 'index';
    }

    public get relativePathToWorkspaceRoot() {
        return '../../';
    }

    public get distRoot() {
        return '../../dist';
    }

    public get componentSelector() {
        return dasherize(this.prefix);
    }

    public get directiveSelector() {
        return camelize(this.prefix);
    }
}
