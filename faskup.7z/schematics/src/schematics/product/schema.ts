export interface Schema {
    name: string;
    path: string;
}
