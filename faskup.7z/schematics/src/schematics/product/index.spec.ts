import { Tree } from '@angular-devkit/schematics';
import { SchematicTestRunner } from '@angular-devkit/schematics/testing';
import * as path from 'path';

const collectionPath = path.join(__dirname, '../../collection.json');

const defaultOptions = {
  name: 'test',
  path: 'products'
}

describe('product', () => {
  it('works', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('product', { ...defaultOptions }, Tree.empty());

    expect(tree.files).toEqual([
      '/products/test/ng-package.json',
      '/products/test/package.json',
      '/products/test/tsconfig.lib.json',
      '/products/test/tsconfig.lib.prod.json',
      '/products/test/tsconfig.spec.json',
      '/products/test/tslint.json',
      '/products/test/src/index.ts'
    ]);
  });
});
