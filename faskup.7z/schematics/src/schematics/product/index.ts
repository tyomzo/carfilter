import { Rule, mergeWith, apply, url, applyTemplates, move } from '@angular-devkit/schematics';
import { ProductContext } from '../../context/product/product';
import { Schema } from './schema';
import { normalize } from 'path';


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function product(options: Schema): Rule {
  const context = new ProductContext(options.name, options.path);
  const path = normalize(`${options.path}/${options.name}`);

    return mergeWith(
      apply(url('./files'), [
        applyTemplates({
          entryFile: context.entryFile,
          context
        }),
        move(path)
    ]));
}
