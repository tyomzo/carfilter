import { ResolveDepsSchema } from './schema';
import { Rule, Tree, SchematicsException, DirEntry, FileEntry } from '@angular-devkit/schematics';
import { getWorkspace } from '@schematics/angular/utility/workspace';
import { NodeDependencyType, addPackageJsonDependency, NodeDependency } from '@schematics/angular/utility/dependencies';
import { JsonAstObject, parseJsonAst, JsonParseMode } from '@angular-devkit/core';
import {
  findPropertyInAstObject,
  appendPropertyInAstObject, insertPropertyInAstObjectInOrder, removePropertyInAstObject
} from '@schematics/angular/utility/json-utils';
import { workspaces } from '@angular-devkit/core';

const importRE = /\} from \'(.*)\';/gm;
const angularRE = /(@angular\/[^\/;]+)\/.+/g;
const stRE = /(@st\/[^\/;]+)\/.+/g;

export function resolveDeps(options: ResolveDepsSchema): Rule {
  return async (host: Tree) => {
    console.log(`Respoving deps for ${options.project}`);
    const workspace = await getWorkspace(host);
    const project = workspace.projects.get(options.project);
    if (!project) {
      throw new SchematicsException(`project '${options.project}' was not found`);
    }
    if (!project.sourceRoot) {
      throw new SchematicsException(`project '${options.project}' sourceRoot is not defined`);
    }
    const imports = [... new Set(traverse(host.getDir(project.sourceRoot)))].sort();
    updateLocalPackageJson(imports, workspace, host, project);
    updateGlobalPackageJson(imports, workspace, host);
    updateNgPackageJson(imports, host, project);
  };
}

function updateGlobalPackageJson(imports: string[], workspace: workspaces.WorkspaceDefinition, host: Tree) {
  imports.filter(i => !i.startsWith('@st')).forEach(i => {
    const globalRef = {
      type: NodeDependencyType.Default,
      name: i,
      version: getVersion(workspace, i, host),
    };
    addPackageJsonDependency(host, globalRef);
  });
}

function updateLocalPackageJson(
  imports: string[], workspace: workspaces.WorkspaceDefinition,
  host: Tree, project: workspaces.ProjectDefinition
) {
  clearLocalPackageJson(project.root, host);
  imports.forEach(i => {
    const localRef = {
      type: NodeDependencyType.Peer,
      name: i,
      version: getVersion(workspace, i, host),
    };
    addLocalPackageJsonDependency(project.root, host, localRef);
  });
}

function updateNgPackageJson(imports: string[], host: Tree, project: workspaces.ProjectDefinition) {
  clearUmbModulesIds(project.root, host);
  imports.forEach(i => addNgPackageUmdModuleId(project.root, host, i));
}

function getVersion(workspace: workspaces.WorkspaceDefinition, pckg: string, tree: Tree) {
  if (pckg.startsWith('@st')) {
    return getWorkspacePackageVersion(workspace, pckg, tree);
  } else {
    return getPackeJsonPackageVersion(pckg, tree);
  }
}

function getWorkspacePackageVersion(workspace: workspaces.WorkspaceDefinition, pckg: string, tree: Tree): string {
  const projectName = pckg.replace('@st/', '');
  const project = workspace.projects.get(projectName);
  if (!project) {
    throw new SchematicsException(`referenced package ${pckg} was not found in workspace`);
  }
  const packageJson = _readPackageJson(project.root, 'package.json', tree);
  const versionNode = packageJson.properties.find(p => p.key.value === 'version');
  if (!versionNode) {
    return 'x.x.x';
  }
  return versionNode.value.value as string;
}

function getPackeJsonPackageVersion(pckg: string, tree: Tree): string {
  const packageJson = _readPackageJson(null, 'package.json', tree);
  const dependencies = findPropertyInAstObject(packageJson, 'dependencies');
  if (!dependencies || dependencies.kind !== 'object') {
    throw new SchematicsException('workspace package.json does not has dependencies');
  }

  const dep = findPropertyInAstObject(dependencies, pckg);

  if (!dep || dep.kind !== 'string') {
    console.warn(`referenced package ${pckg} was not found global package.json. run 'npm install --save ${pckg}'`);
    return 'x.x.x'
  }

  return dep.value;
}

function traverse(dir: DirEntry): string[] {
  let results = [] as string[];
  dir.subfiles
    .filter(f => f.endsWith('.ts'))
    .filter(f => f.indexOf('.spec.') === -1)
    .map(f => dir.file(f))
    .filter(f => !!f)
    .forEach((f: FileEntry) => {
      const imports = processFile(f);
      if (!!imports && imports.length) {
        results = [...results, ...imports];
      }
    });
  dir.subdirs
    .filter(d => d.indexOf('node_module') === -1)
    .forEach(d => {
      const nested = traverse(dir.dir(d));
      if (!!nested && nested.length) {
        results = [...results, ...nested];
      }
    });
  return results.filter(f => notLocalReference(f)).map(f => collapseLibs(f));
}

function collapseLibs(f: string) {
  if (f.startsWith('rxjs/')) {
    return 'rxjs';
  }

  if (f.startsWith('primeng/')) {
    return 'primeng';
  }

  const angularPackage = angularRE.exec(f);
  if (!!angularPackage && angularPackage.length === 2) {
    return angularPackage[1];
  }

  const stPackage = stRE.exec(f);
  if (!!stPackage && stPackage.length === 2) {
    return stPackage[1];
  }

  return f;
}

function notLocalReference(f: string) {
  return !f.startsWith('.');
}

function processFile(file: FileEntry): string[] {
  const results = [];
  const content = file.content.toString();
  let result = importRE.exec(content);
  while (!!result) {
    if (result.length === 2) {
      results.push(result[1]);
    }
    result = importRE.exec(content);
  }
  return results;
}

export function addNgPackageUmdModuleId(dir: string, tree: Tree, pkg: string): void {
  const packageJsonAst = _readPackageJson(dir, 'ng-package.json', tree);
  const recorder = tree.beginUpdate(`${dir}/ng-package.json`);
  let libNode = findPropertyInAstObject(packageJsonAst, 'lib');
  if (!libNode || libNode.kind !== 'object') {
    appendPropertyInAstObject(recorder, packageJsonAst, 'lib', { ['umdModuleIds']: null }, 4);
    libNode = findPropertyInAstObject(packageJsonAst, 'lib');
  }
  if (!libNode || libNode.kind !== 'object') {
    throw new SchematicsException(`Failed to get 'lib' node of ${dir}/ng-package.json`);
  }
  const umdIds = findPropertyInAstObject(libNode, 'umdModuleIds');
  if (!umdIds || umdIds.kind !== 'object') {
    appendPropertyInAstObject(recorder, libNode, 'umdModuleIds', { [pkg]: pkg, }, 4);
  } else {
    insertPropertyInAstObjectInOrder(recorder, umdIds, pkg, pkg, 4);
  }

  tree.commitUpdate(recorder);
}

function clearUmbModulesIds(dir: string, tree: Tree) {
  const packageJsonAst = _readPackageJson(dir, 'ng-package.json', tree);
  const recorder = tree.beginUpdate(`${dir}/ng-package.json`);
  let libNode = findPropertyInAstObject(packageJsonAst, 'lib');
  if (!libNode || libNode.kind !== 'object') {
    return;
  }
  removePropertyInAstObject(recorder, libNode, 'umdModuleIds');
  tree.commitUpdate(recorder);
}

function clearLocalPackageJson(dir: string, tree: Tree) {
  const packageJsonAst = _readPackageJson(dir, 'package.json', tree);
  const recorder = tree.beginUpdate(`${dir}/package.json`);
  let deps = findPropertyInAstObject(packageJsonAst, 'peerDependencies');
  if (!deps) {
    return;
  }
  removePropertyInAstObject(recorder, packageJsonAst, 'peerDependencies');
  tree.commitUpdate(recorder);
}


export function addLocalPackageJsonDependency(dir: string, tree: Tree, dependency: NodeDependency): void {
  const packageJsonAst = _readPackageJson(dir, 'package.json', tree);
  const depsNode = findPropertyInAstObject(packageJsonAst, dependency.type);
  const recorder = tree.beginUpdate(`${dir}/package.json`);
  if (!depsNode) {
    // Haven't found the dependencies key, add it to the root of the package.json.
    appendPropertyInAstObject(recorder, packageJsonAst, dependency.type, { [dependency.name]: dependency.version, }, 4);
  } else if (depsNode.kind === 'object') {
    // check if package already added
    const depNode = findPropertyInAstObject(depsNode, dependency.name);

    if (!depNode) {
      // Package not found, add it.
      insertPropertyInAstObjectInOrder(
        recorder,
        depsNode,
        dependency.name,
        dependency.version,
        4,
      );
    } else if (dependency.overwrite) {
      // Package found, update version if overwrite.
      const { end, start } = depNode;
      recorder.remove(start.offset, end.offset - start.offset);
      recorder.insertRight(start.offset, JSON.stringify(dependency.version));
    }
  }

  tree.commitUpdate(recorder);
}

function _readPackageJson(dir: string | null, file: string, tree: Tree): JsonAstObject {
  const path = !!dir ? `${dir}/` : '';
  const buffer = tree.read(`${path}${file}`);
  if (buffer === null) {
    throw new SchematicsException(`Could not read ${path}${file}.`);
  }
  const content = buffer.toString();

  const packageJson = parseJsonAst(content, JsonParseMode.Strict);
  if (packageJson.kind !== 'object') {
    throw new SchematicsException(`Invalid ${path}${file}}. Was expecting an object`);
  }

  return packageJson;
}
