export interface ResolveDepsSchema {
  project: string;
}
