export interface ServiceSchema {
    name: string;
    path: string;
    packageRoot: string;
}
