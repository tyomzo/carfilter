import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { ServiceSchema } from './schema';
import { entityStateContextFactory } from '../../../context/entity/entityStateContextFactory';


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function service(options: ServiceSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    const context = entityStateContextFactory(options.name, options.packageRoot, options.name);
    const templateSource = apply(url('./files'), [
      applyTemplates({
        fileName: context.service.fileName,
        context: context.service
      }),
      move(normalize(options.path as string))
    ]);

    return chain([
      mergeWith(templateSource)
    ]);
  };
}
