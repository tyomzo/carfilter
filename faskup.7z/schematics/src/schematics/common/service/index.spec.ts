import { Tree } from '@angular-devkit/schematics';
import { SchematicTestRunner } from '@angular-devkit/schematics/testing';
import * as path from 'path';


const collectionPath = path.join(__dirname, '../../../collection.json');


describe('service', () => {
  it('works', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('service', {name: 'Test', path: '/src/app', packageRoot: '@st/schematics/test'}, Tree.empty());

    expect(tree.files).toContain('/src/app/services/test.service.ts');
  });
});
