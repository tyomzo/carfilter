import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { EntityContext } from "../../../context/entity/entity";
import { normalize } from 'path';
import { Schema } from './schema';

export function models(options: Schema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    
    const entityContext = new EntityContext(options.name, options.packageRoot, options.name);

    const templateSource = apply(url('./files'), [
      applyTemplates({
        readModelFileName: entityContext.models.read.fileName,
        createModelFileName: entityContext.models.create.fileName,
        updateModelFileName: entityContext.models.update.fileName,
        deleteModelFileName: entityContext.models.delete.fileName,
        context: entityContext.models
      }),
      move(normalize(options.path as string))
    ]);

    return chain([
      mergeWith(templateSource)
    ]);
  };
}
