import { Tree } from '@angular-devkit/schematics';
import { SchematicTestRunner } from '@angular-devkit/schematics/testing';
import * as path from 'path';

const collectionPath = path.join(__dirname, '../../../collection.json');

const defaultOptions = {
  name: 'MyEntity',
  path: '/src/app', 
  packageRoot: '@st/schematics/test'
};

describe('models', () => {
  it('works', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('models', { ...defaultOptions }, Tree.empty());

    expect(tree.files.length).toBeGreaterThan(0);
  });

  it('read model created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('models', { ...defaultOptions }, Tree.empty());

    expect(tree.files).toContain('/src/app/models/my-entity-read.ts');
  });

  it('create model created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('models', { ...defaultOptions }, Tree.empty());

    expect(tree.files).toContain('/src/app/models/my-entity-read.ts');
  });

  it('update model created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('models', { ...defaultOptions }, Tree.empty());

    expect(tree.files).toContain('/src/app/models/my-entity-update.ts');
  });

  it('delete model created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('models', { ...defaultOptions }, Tree.empty());

    expect(tree.files).toContain('/src/app/models/my-entity-delete.ts');
  });
});
