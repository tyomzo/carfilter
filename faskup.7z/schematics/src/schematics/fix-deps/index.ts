import { Rule, Tree, schematic, chain } from '@angular-devkit/schematics';
import { getWorkspace } from '@schematics/angular/utility/workspace';

export function fixDeps(_options: any): Rule {
  return async (host: Tree) => {
    const workspace = await getWorkspace(host);
    const projects = [] as string[];
    for (let key of workspace.projects.keys()) {
      projects.push(key);
    }
    return chain(projects.map(p => schematic('resolve-deps', { project: p })));
  };
}
