export interface EntityUpdateStateSchema {
    name: string;
    path: string;
    packageRoot: string;
}
