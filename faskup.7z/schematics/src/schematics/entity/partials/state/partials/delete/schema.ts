export interface EntityDeleteStateSchema {
    name: string;
    path: string;
    packageRoot: string;
    operations: string;
}
