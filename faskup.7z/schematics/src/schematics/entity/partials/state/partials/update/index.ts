import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";
import { EntityUpdateStateSchema } from './schema';


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function entityUpdateState(options: EntityUpdateStateSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    const entityContext = new EntityContext(options.name, options.packageRoot, options.name);

    const templateSource = apply(url('./files'), [
      applyTemplates({
        updateActionsFileName: entityContext.state.actions.update.fileName,
        updateEffectsFileName: entityContext.state.effects.update.fileName,
        updateReducerFileName: entityContext.state.reducer.update.fileName,
        context: entityContext.state
      }),
      move(normalize(options.path as string))
    ]);

    return chain([
      mergeWith(templateSource)
    ]);
  };
}
