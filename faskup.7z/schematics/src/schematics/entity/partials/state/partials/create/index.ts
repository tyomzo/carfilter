import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { EntityCreateStateSchema } from './schema';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function entityCreateState(options: EntityCreateStateSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    const entityContext = new EntityContext(options.name, options.packageRoot, options.name);

    const templateSource = apply(url('./files'), [
      applyTemplates({
        createActionsFileName: entityContext.state.actions.create.fileName,
        createEffectsFileName: entityContext.state.effects.create.fileName,
        createReducerFileName: entityContext.state.reducer.create.fileName,
        context: entityContext.state
      }),
      move(normalize(options.path as string))
    ]);

    return chain([
      mergeWith(templateSource)
    ]);
  };
}
