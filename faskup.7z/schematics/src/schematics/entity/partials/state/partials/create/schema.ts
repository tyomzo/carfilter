export interface EntityCreateStateSchema {
    name: string;
    path: string;
    packageRoot: string;
    operations: string;
}
