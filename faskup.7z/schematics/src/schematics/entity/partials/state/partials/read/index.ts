import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { EntityReadStateSchema } from './schema';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function entityReadState(options: EntityReadStateSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    const entityContext = new EntityContext(options.name, options.packageRoot, options.name);

    const templateSource = apply(url('./files'), [
      applyTemplates({
        readActionsFileName: entityContext.state.actions.read.fileName,
        readEffectsFileName: entityContext.state.effects.read.fileName,
        readReducerFileName: entityContext.state.reducer.read.fileName,
        context: entityContext.state
      }),
      move(normalize(options.path as string))
    ]);

    return chain([
      mergeWith(templateSource)
    ]);
  };
}
