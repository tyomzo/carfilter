export interface EntityReadStateSchema {
    name: string;
    path: string;
    packageRoot: string;
}
