import { Tree } from '@angular-devkit/schematics';
import { SchematicTestRunner, UnitTestTree } from '@angular-devkit/schematics/testing';
import * as path from 'path';

const collectionPath = path.join(__dirname, '../../../../../collection.json');

const defaultOptions = {
  name: 'test',
  path: '/src/app',
  packageRoot: '@st/schematics/test',
  operations: 'crud'
};

describe('entity-state', () => {
  it('facade is created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-state', { ...defaultOptions });

    expect(tree.files).toContain('/src/app/state/test.facade.ts');
  });

  it('state is created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-state', { ...defaultOptions });

    expect(tree.files).toContain('/src/app/state/test.state.ts');
  });

  it('reducer is created', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-state', { ...defaultOptions });

    expect(tree.files).toContain('/src/app/state/reducers/test.reducer.ts');
  });

  describe('Read', () => {
    it('actions are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/actions/test-read.actions.ts');
    });

    it('actions are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cud' });

      expect(tree.files).not.toContain('/src/app/state/actions/test-read.actions.ts');
    });

    it('effects are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/effects/test-read.effects.ts');
    });

    it('effects are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cud' });

      expect(tree.files).not.toContain('/src/app/state/effects/test-read.effects.ts');
    });

    it('reducer is created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/reducers/test-read.reducer.ts');
    });

    it('reducer is not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cud' });

      expect(tree.files).not.toContain('/src/app/state/reducers/test-read.reducer.ts');
    });
  });

  describe('Create', () => {
    it('actions are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/actions/test-create.actions.ts');
    });

    it('actions are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'rud' });

      expect(tree.files).not.toContain('/src/app/state/actions/test-create.actions.ts');
    });

    it('effects are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/effects/test-create.effects.ts');
    });

    it('effects are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'rud' });

      expect(tree.files).not.toContain('/src/app/state/effects/test-create.effects.ts');
    });

    it('reducer is created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/reducers/test-create.reducer.ts');
    });

    it('reducer is not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'rud' });

      expect(tree.files).not.toContain('/src/app/state/reducers/test-create.reducer.ts');
    });
  });

  describe('Update', () => {
    it('actions are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/actions/test-update.actions.ts');
    });

    it('actions are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'crd' });

      expect(tree.files).not.toContain('/src/app/state/actions/test-update.actions.ts');
    });

    it('effects are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/effects/test-update.effects.ts');
    });

    it('effects are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'crd' });

      expect(tree.files).not.toContain('/src/app/state/effects/test-update.effects.ts');
    });

    it('reducer is created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/reducers/test-update.reducer.ts');
    });

    it('reducer is not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'crd' });

      expect(tree.files).not.toContain('/src/app/state/reducers/test-update.reducer.ts');
    });
  });

  describe('Delete', () => {
    it('actions are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/actions/test-delete.actions.ts');
    });

    it('actions are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cru' });

      expect(tree.files).not.toContain('/src/app/state/actions/test-delete.actions.ts');
    });

    it('effects are created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/effects/test-delete.effects.ts');
    });

    it('effects are not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cru' });

      expect(tree.files).not.toContain('/src/app/state/effects/test-delete.effects.ts');
    });

    it('reducer is created', () => {
      const tree = runSchematic({ ...defaultOptions });

      expect(tree.files).toContain('/src/app/state/reducers/test-delete.reducer.ts');
    });

    it('reducer is not created', () => {
      const tree = runSchematic({ ...defaultOptions, operations: 'cru' });

      expect(tree.files).not.toContain('/src/app/state/reducers/test-delete.reducer.ts');
    });
  });

  function runSchematic(options: any): UnitTestTree {
    return new SchematicTestRunner('schematics', collectionPath)
      .runSchematic('entity-state', options, Tree.empty());
  }
});
