export interface ComponentSchema {
    name: string;
    path: string;
    packageRoot: string;
    operations: string;
}
