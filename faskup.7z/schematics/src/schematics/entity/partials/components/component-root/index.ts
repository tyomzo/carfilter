import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith, schematic } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { ComponentSchema } from './schema';
import { EntityContext } from "../../../../../context/entity/entity";


// You don't have to export the function as default. You can also have more than one rule factory
// per file.
export function component(options: ComponentSchema): Rule {
    return (_tree: Tree, _context: SchematicContext) => {
        const entityContext = new EntityContext(options.name, options.packageRoot, options.name);

        const create = !!options.operations ? options.operations.includes("c") : true;
        const read = !!options.operations ? options.operations.includes("r") : true;
        const update = !!options.operations ? options.operations.includes("u") : true;
        const del = !!options.operations ? options.operations.includes("d") : true;

        const templateSource = apply(url('./files'), [
            applyTemplates({
                fileName: entityContext.component.fileName,
                context: entityContext.component,

                create,
                read,
                update,
                del
            }),
            move(normalize(options.path as string))
        ])

        const componentOptions = {
            name: options.name,
            path: options.path,
            packageRoot: entityContext.rootPath
        };

        const rules = [mergeWith(templateSource)];
        if (create) {
            rules.push(schematic('entity-create-component', componentOptions));
        }
        if (read) {
            rules.push(schematic('entity-read-component', componentOptions));
        }
        if (update) {
            rules.push(schematic('entity-update-component', componentOptions));
        }
        if (del) {
            rules.push(schematic('entity-delete-component', componentOptions));
        }

        return chain(rules);
    };
}
