import { Tree } from '@angular-devkit/schematics';
import { SchematicTestRunner } from '@angular-devkit/schematics/testing';
import * as path from 'path';


const collectionPath = path.join(__dirname, '../../../../../collection.json');

const options = {
  name: 'test',
  path: 'src/test',
  packageRoot: '@st/entity-component'
}


describe('entity-component', () => {
  it('has more than 0 file', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-component', options, Tree.empty());

    expect(tree.files.length).toBeGreaterThan(0);
  });

  it('contains component ts template', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-component', options, Tree.empty());

    expect(tree.files).toContain(`/${options.path}/components/test.component.ts`);
  });

  it('contains component html template', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-component', options, Tree.empty());

    expect(tree.files).toContain(`/${options.path}/components/test.component.html`);
  });

  it('contains component css template', () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = runner.runSchematic('entity-component', options, Tree.empty());

    expect(tree.files).toContain(`/${options.path}/components/test.component.css`);
  });
});
