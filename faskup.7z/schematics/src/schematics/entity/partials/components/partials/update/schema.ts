export interface UpdateComponentSchema {
    name: string;
    path: string;
    packageRoot: string;
}
