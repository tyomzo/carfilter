import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";
import { CreateComponentSchema } from './schema';

export function entityCreateComponent(options: CreateComponentSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
      const entityContext = new EntityContext(options.name, options.packageRoot, options.name);
      const templateSource = apply(url('./files'), [
          applyTemplates({
              fileName: entityContext.component.create.fileName,
              context: entityContext.component.create
          }),
          move(normalize(options.path as string))
      ])

      return chain([
          mergeWith(templateSource)
      ])
  };
}
