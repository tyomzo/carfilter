import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";
import { DeleteComponentSchema } from './schema';

export function entityDeleteComponent(options: DeleteComponentSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
      const entityContext = new EntityContext(options.name, options.packageRoot, options.name);
      const templateSource = apply(url('./files'), [
          applyTemplates({
              fileName: entityContext.component.delete.fileName,
              context: entityContext.component.delete
          }),
          move(normalize(options.path as string))
      ])

      return chain([
          mergeWith(templateSource)
      ])
  };
}
