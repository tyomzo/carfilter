export interface DeleteComponentSchema {
    name: string;
    path: string;
    packageRoot: string;
}
