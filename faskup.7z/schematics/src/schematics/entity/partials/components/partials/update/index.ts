import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith } from '@angular-devkit/schematics';
import { normalize } from 'path';
import { EntityContext } from "../../../../../../context/entity/entity";
import { UpdateComponentSchema } from './schema';

export function entityUpdateComponent(options: UpdateComponentSchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
      const entityContext = new EntityContext(options.name, options.packageRoot, options.name);
      const templateSource = apply(url('./files'), [
          applyTemplates({
              fileName: entityContext.component.update.fileName,
              context: entityContext.component.update
          }),
          move(normalize(options.path as string))
      ])

      return chain([
          mergeWith(templateSource)
      ])
  };
}
