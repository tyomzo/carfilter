export interface CreateComponentSchema {
    name: string;
    path: string;
    packageRoot: string;
}
