export interface ReadComponentSchema {
    name: string;
    path: string;
    packageRoot: string;
}
