export interface Schema {
    name: string;
    path: string;
    packageRoot: string;
    operations: string;
}
