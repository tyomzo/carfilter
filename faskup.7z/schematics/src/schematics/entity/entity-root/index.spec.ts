import { SchematicTestRunner, UnitTestTree } from '@angular-devkit/schematics/testing';
import * as path from 'path';
import { createWorkspace } from '../../../testing/create-workspace';

const collectionPath = path.join(__dirname, '../../../collection.json');
const runner = new SchematicTestRunner('schematics', collectionPath);

let appTree: UnitTestTree;

// const appPath = `${getTestProjectPath()}/src/app`;

const defaultOptions = {
  name: 'MyEntity',
  path: '/src/app', 
  packageRoot: '@st/schematics/test'
};

beforeEach(async () => {
  appTree = await createWorkspace(runner, appTree);
});

describe('entity', () => {
  it('works', () => {
    const tree = runner.runSchematic('entity', { ...defaultOptions }, appTree);
    const files = tree.files;
    
    expect(files.length).toBeGreaterThan(0);
  });
});
