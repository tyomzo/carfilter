import { Rule, SchematicContext, Tree, apply, url, applyTemplates, move, chain, mergeWith, schematic } from '@angular-devkit/schematics';
import { Schema as EntitySchema } from './schema';
import { normalize, } from '@angular-devkit/core';
import { ServiceSchema } from '../../common/service/schema';
import { EntityContext } from '../../../context/entity/entity';
import { EntityStateSchema } from '../partials/state/state-root/schema';
import { ComponentSchema } from '../partials/components/component-root/schema';

export function entity(options: EntitySchema): Rule {
  return (_tree: Tree, _context: SchematicContext) => {
    const entityContext = new EntityContext(options.name, options.packageRoot, options.name);
    const path = normalize(`${options.path}/${options.name}`);

    const templateSource = apply(url('./files'), [
      applyTemplates({
        fileName: entityContext.fileName,
        context: entityContext
      }),
      move(path)
    ]);

    const modelsOptions: ServiceSchema = {
      name: options.name,
      path: path,
      packageRoot: entityContext.rootPath
    }

    const stateOptions: EntityStateSchema = {
      name: options.name,
      path: path,
      packageRoot: entityContext.rootPath,
      operations: options.operations
    }

    const serviceOptions: ServiceSchema = {
      name: options.name,
      path: path,
      packageRoot: entityContext.rootPath
    }

    const componentOptions: ComponentSchema = {
      name: options.name,
      path: path,
      packageRoot: entityContext.rootPath,
      operations: options.operations
    }

    return chain([
      mergeWith(templateSource),
      schematic('models', modelsOptions),
      schematic('service', serviceOptions),
      schematic('entity-state', stateOptions),
      schematic('entity-component', componentOptions)
    ]);
  };
}
