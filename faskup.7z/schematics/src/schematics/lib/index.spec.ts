import { SchematicTestRunner, UnitTestTree } from '@angular-devkit/schematics/testing';
import * as path from 'path';

const angularRunner = new SchematicTestRunner(
  '@schematics/ng_packagr',
  require.resolve('../../../node_modules/@schematics/angular/collection.json'),
);

const collectionPath = path.join(__dirname, '../../collection.json');

const workspaceOptions = {
  name: 'workspace',
  newProjectRoot: 'projects',
  version: '6.0.0',
};

let workspaceTree: UnitTestTree;
beforeEach(async () => {
  workspaceTree = await angularRunner.runSchematicAsync('workspace', workspaceOptions).toPromise();
});

const defaultOptions = {
  name: "my-lib",
  path: "shared"
};

describe('lib', () => {
  it('works', async () => {
    const runner = new SchematicTestRunner('schematics', collectionPath);
    const tree = await runner.runSchematicAsync('library', { ...defaultOptions }, workspaceTree).toPromise();

    expect(tree.files).toContain('/shared/my-lib/src/public-api.ts');
  });
});
