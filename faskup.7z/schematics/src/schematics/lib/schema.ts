export interface LibrarySchema {
    name: string;
    path: string;
}
