import { Rule, applyTemplates, apply, url, move, chain, mergeWith, Tree, SchematicsException } from '@angular-devkit/schematics';
import { LibrarySchema } from './schema';
// import { getWorkspace, updateWorkspace } from '@schematics/angular/utility/workspace';
import { relativePathToWorkspaceRoot } from '@schematics/angular/utility/paths';
import { ProjectType, Builders } from '@schematics/angular/utility/workspace-models';
import { updateWorkspace } from '@schematics/angular/utility/workspace';
import { NodeDependencyType, addPackageJsonDependency } from '@schematics/angular/utility/dependencies';
import { strings, join, normalize, parseJson, JsonParseMode } from '@angular-devkit/core';

interface UpdateJsonFn<T> {
  (obj: T): T | void;
}

type TsConfigPartialType = {
  compilerOptions: {
    baseUrl: string,
    paths: {
      [key: string]: string[];
    },
  },
};

const directiveSelector = 'st';
const componentSelector = 'st';
const prefix = 'st';
const supportedVersions = {
  Angular: "~7.2.0",
  DevkitBuildNgPackagr: "~0.13.0",
  DevkitBuildAngular: "~0.13.0",
  ngPackagr: "^4.2.0",
  TsLib: "~1.9.0",
  TypeScript: "~3.2.2"
}

function updateJsonFile<T>(host: Tree, path: string, callback: UpdateJsonFn<T>): Tree {
  const source = host.read(path);
  if (source) {
    const sourceText = source.toString('utf-8');
    const json = parseJson(sourceText, JsonParseMode.Loose);
    callback(json as {} as T);
    host.overwrite(path, JSON.stringify(json, null, 2));
  }

  return host;
}

function updateTsConfig(packageName: string, distRoot: string) {

  return (host: Tree) => {
    if (!host.exists('tsconfig.json')) { return host; }

    return updateJsonFile(host, 'tsconfig.json', (tsconfig: TsConfigPartialType) => {
      if (!tsconfig.compilerOptions.paths) {
        tsconfig.compilerOptions.paths = {};
      }
      if (!tsconfig.compilerOptions.paths[packageName]) {
        tsconfig.compilerOptions.paths[packageName] = [];
      }
      tsconfig.compilerOptions.paths[packageName].push(distRoot);
    });
  };
}

function addDependenciesToPackageJson() {

  return (host: Tree) => {
    [
      {
        type: NodeDependencyType.Dev,
        name: '@angular/compiler-cli',
        version: supportedVersions.Angular,
      },
      {
        type: NodeDependencyType.Dev,
        name: '@angular-devkit/build-ng-packagr',
        version: supportedVersions.DevkitBuildNgPackagr,
      },
      {
        type: NodeDependencyType.Dev,
        name: '@angular-devkit/build-angular',
        version: supportedVersions.DevkitBuildAngular,
      },
      {
        type: NodeDependencyType.Dev,
        name: 'ng-packagr',
        version: supportedVersions.ngPackagr,
      },
      {
        type: NodeDependencyType.Default,
        name: 'tslib',
        version: supportedVersions.TsLib,
      },
      {
        type: NodeDependencyType.Dev,
        name: 'typescript',
        version: supportedVersions.TypeScript,
      },
    ].forEach(dependency => addPackageJsonDependency(host, dependency));

    return host;
  };
}

function addLibToWorkspaceFile(projectRoot: string, projectName: string): Rule {
  return updateWorkspace(workspace => {
    if (workspace.projects.size === 0) {
      workspace.extensions.defaultProject = projectName;
    }

    workspace.projects.add({
      name: projectName,
      root: projectRoot,
      sourceRoot: `${projectRoot}/src`,
      projectType: ProjectType.Library,
      prefix: prefix,
      targets: {
        build: {
          builder: Builders.NgPackagr,
          options: {
            tsConfig: `${projectRoot}/tsconfig.lib.json`,
            project: `${projectRoot}/ng-package.json`,
          },
          configurations: {
            production: {
              tsConfig: `${projectRoot}/tsconfig.lib.prod.json`,
            },
          },
        },
        // test: {
        //   builder: Builders.Karma,
        //   options: {
        //     main: `${projectRoot}/src/test.ts`,
        //     tsConfig: `${projectRoot}/tsconfig.spec.json`,
        //     karmaConfig: `${projectRoot}/karma.conf.js`,
        //   },
        // },
        lint: {
          builder: Builders.TsLint,
          options: {
            tsConfig: [
              `${projectRoot}/tsconfig.lib.json`,
              `${projectRoot}/tsconfig.spec.json`,
            ],
            exclude: [
              '**/node_modules/**',
            ],
          },
        },
      },
    });
  });
}

export function library(options: LibrarySchema): Rule {
  return async (_host: Tree) => {
    if (!options.name) {
      throw new SchematicsException(`Invalid options, "name" is required.`);
    }
    // const workspace = await getWorkspace(host);

    const folderName = join(normalize(options.path), normalize(options.name));
    const packageName = `@st/${strings.dasherize(options.name)}`;
    const distRoot = `dist/${folderName}`;
    // const sourceDir = `${folderName}/src/lib`;

    const templateSource = apply(url('./files'), [
      applyTemplates({
        relativePathToWorkspaceRoot: relativePathToWorkspaceRoot(folderName),
        distRoot,
        packageName,
        directiveSelector,
        componentSelector
      }),
      move(folderName)
    ]);
    return chain([
      mergeWith(templateSource),
      addLibToWorkspaceFile(folderName, options.name),
      addDependenciesToPackageJson(),
      updateTsConfig(packageName, distRoot)
    ]);
  };
}
