async function copy() {
    const fs = require('fs-extra');
    const srcRoot = './src';
    const distRoot = '../dist/schematics';
    const collection = 'collection.json';
    const schema = 'schema.json';
    const templates = '.template'

    async function copyCollectionDefinition() {

        if (!(await fs.exists(`${srcRoot}/${collection}`))) {
            throw new Error(`${collection} was not found`);
        }
        await fs.copy(`${srcRoot}/${collection}`, `${distRoot}/${collection}`);
    }

    async function copySchemasAndTemplates(folder) {
        const folders = await fs.readdir(folder);
        for (let i = 0; i < folders.length; i++) {
            const path = folders[i];
            const stats = await fs.stat(`${folder}/${path}`);
            if (stats.isDirectory()) {
                copySchemasAndTemplates
                    (`${folder}/${path}`);
            } else if (stats.isFile() && isTemplateOrSchema(path)) {
                await copyToDist(folder, path);
            }
        }
    }

    async function copyToDist(folder, path) {
        const dist = folder.replace(srcRoot, distRoot);
        await fs.ensureDir(dist);
        await fs.copyFile(`${folder}/${path}`, `${dist}/${path}`);
    }

    function isTemplateOrSchema(path) {
        return path.endsWith(templates) || path === schema;
    }

    await copyCollectionDefinition();
    await copySchemasAndTemplates(srcRoot);

};

copy();
