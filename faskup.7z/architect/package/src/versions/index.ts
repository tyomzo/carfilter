import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { PublishOptions } from './schema';
import { getWorkspace } from '../utils/workspace';
import { readPackageInfoFast } from '../utils/npm';


type ExecuteBuildOptions = JsonObject & PublishOptions;
export default createBuilder<ExecuteBuildOptions>(executePublish);

export async function executePublish(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  const workspace = getWorkspace();

  const projects = workspace.modules;

  context.logger.info('Getting packages information from npm repository');

  for (let i = 0; i < projects.length; i++) {
    const project = projects[i];
    const info = await readPackageInfoFast(project);
    context.logger.info(`"@st/${project.name}": "^${info.version}"`);
  };

  return Promise.resolve({ success: true });
}
