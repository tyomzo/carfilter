import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { BootstrapOptions } from './schema';
import { getWorkspace, Project } from '../utils/workspace';
import * as fs from 'fs';


type ExecuteBuildOptions = JsonObject & BootstrapOptions;
export default createBuilder<ExecuteBuildOptions>(executePublish);

export async function executePublish(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  context.logger.info('Deleting links');
  const workspace = getWorkspace();
  workspace.allProjects().forEach(pkg => {
    deleteNodeModules(pkg);
  });

  return Promise.resolve({ success: true });
}

export function deleteNodeModules(pkg: Project) {
  const target = `${pkg.root}/node_modules`;
  if(fs.existsSync(target)) {
    fs.rmdirSync(target);
  }
}
