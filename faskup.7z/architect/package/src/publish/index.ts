import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { PublishOptions } from './schema';
import { getWorkspace, readPackageJson, savePackageJson, getDistPath } from '../utils/workspace';
import { buildHashMap } from '../utils/hash';
import { publishPackage, PackageVersions, readPackageInfoFast } from '../utils/npm';
import * as semver from 'semver';


type ExecuteBuildOptions = JsonObject & PublishOptions;
export default createBuilder<ExecuteBuildOptions>(executePublish);

export async function executePublish(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  const workspace = getWorkspace();

  const projects = workspace.modules;

  context.logger.info('Calculating local hashes');

  const localHashMap = buildHashMap(projects);

  context.logger.info('Getting packages information from npm repository');

  const remotePackages = {} as PackageVersions;

  for (let i = 0; i < projects.length; i++) {
    const project = projects[i];
    remotePackages[project.name] = await readPackageInfoFast(project)
  }

  const candidates = projects.filter(p => localHashMap[p.name] !== remotePackages[p.name].hash);

  context.logger.info(`Found ${candidates.length} packages to publish`);

  const build = await context.scheduleBuilder('@st-devkit/build-package:build', {});
  const buildResult = await build.result;

  if (!buildResult.success) {
    throw new Error('Refuse to publish. Failed to build workspace');
  }

  candidates.forEach(project => {
    context.logger.info(`Publishing ${project.root}`);

    if (!remotePackages[project.name]) {
      remotePackages[project.name].version = '0.0.0';
    }
    const newVersion = semver.inc(remotePackages[project.name].version, 'patch') as string;
    context.logger.info(`${project.name} version increment: ${remotePackages[project.name].version} -> ${newVersion}`);
    remotePackages[project.name].version = newVersion;

    const dist = getDistPath(project);

    const packageJson = readPackageJson(dist);
    packageJson.hash = localHashMap[project.name];
    packageJson.version = remotePackages[project.name].version;
    savePackageJson(dist, packageJson);

    publishPackage(dist);
  });

  return Promise.resolve({ success: true });
}
