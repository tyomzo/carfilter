import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { HashOptions } from './schema';
import { readProject } from '../utils/workspace';
import { getProjectHash } from '../utils/hash';


type ExecuteBuildOptions = JsonObject & HashOptions;
export default createBuilder<ExecuteBuildOptions>(executeHash);

export async function executeHash(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  let result: BuilderOutput;

  if (!context.target) {
    context.logger.error('target is not specified');
    result = { success: false};
    return Promise.resolve(result);
  }

  context.logger.info(context.target.project);

  const project = readProject(context.target.project);
  const hash = getProjectHash(project);

  context.logger.info(`Project ${project.name} has: ${hash}`);

  return Promise.resolve({ success: true});
}
