export interface HashOptions {

}
