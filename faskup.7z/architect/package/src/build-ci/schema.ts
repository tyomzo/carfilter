export interface BuildOptions {
  projects: string[];
}
