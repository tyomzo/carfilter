import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { BuildOptions } from './schema';
import { getWorkspace } from '../utils/workspace';
import { getBuildOrder } from '../utils/dep-tree';
import { runBuild, Semaphore } from '../utils/builder';
import { elapsed } from '../utils/timer';


type ExecuteBuildOptions = JsonObject & BuildOptions;
export default createBuilder<ExecuteBuildOptions>(executeBuild);

export async function executeBuild(options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  let result: BuilderOutput;
  try {
    const workspace = getWorkspace();

    const projects = workspace.modules.filter(p => options.projects.findIndex(c => p.name === c) !== -1);

    context.logger.info(`Building ${projects.length} packages`);

    const queue = getBuildOrder(projects).filter(n => projects.findIndex(p => p.name === n.name) !== -1);

    let currentLevel = 0;
    const total = queue.length;
    context.reportProgress(0, total);
    const semaphore = new Semaphore(7);
    const startTime = new Date();
    while (queue.length > 0) {
      const project = queue.shift();
      if (!!project) {
        if (project.order !== currentLevel) {
          await semaphore.waitAll();
          currentLevel = project.order;
        }
        const task = async () => {
          context.logger.info(`Building ${project.name}`);
          await runBuild(project.name, context);
          context.logger.info(`Completed ${project.name}`);
        };

        semaphore.add(task());
      }
      context.reportProgress(total - queue.length, total);
    }

    await semaphore.waitAll();

    const endTime = new Date();
    context.logger.info(`Elapsed: ${elapsed(startTime, endTime)}`);
    result = { success: true };
  } catch (e) {
    context.logger.error('Failed to build workspace', e);
    result = { success: false, error: e };
  }

  return Promise.resolve(result);
}
