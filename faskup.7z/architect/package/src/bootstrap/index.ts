import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { BootstrapOptions } from './schema';
import { getWorkspace, Project } from '../utils/workspace';
import { getBuildOrder } from '../utils/dep-tree';
import * as fs from 'fs';


type ExecuteBuildOptions = JsonObject & BootstrapOptions;
export default createBuilder<ExecuteBuildOptions>(executePublish);

export async function executePublish(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  const workspace = getWorkspace();
  const queue = getBuildOrder([workspace.app]);
  queue.forEach(pkg => {
    Object.keys(pkg.in).forEach(dep => {
      context.logger.info(`linking ${pkg.name} to ${dep}`);
      createSymlink(workspace.projects[pkg.name], workspace.projects[dep])
    });
  });

  return Promise.resolve({ success: true });
}

export function createSymlink(source: Project, target: Project) {
  const sourceNodeModules = `${source.root}/node_modules/`;
  const symlinkLocation = `${sourceNodeModules}@st/`
  if(!fs.existsSync(sourceNodeModules)) {
    fs.mkdirSync(sourceNodeModules);
  }
  if(!fs.existsSync(symlinkLocation)) {
    fs.mkdirSync(symlinkLocation);
  }
  const symlink = `${symlinkLocation}${target.name}`;
  if(!fs.existsSync(symlink)) {
    return fs.symlinkSync(target.root, symlink, 'dir');
  }
}
