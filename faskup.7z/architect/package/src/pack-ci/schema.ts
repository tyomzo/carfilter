export interface PublishOptions {
  increment: 'Minor' | 'Patch';
}
