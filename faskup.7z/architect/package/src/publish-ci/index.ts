import { BuilderOutput, createBuilder, BuilderContext } from '@angular-devkit/architect';
import { JsonObject } from '@angular-devkit/core';
import { PublishOptions } from './schema';
import { getWorkspace, readPackageJson, savePackageJson, getDistPath } from '../utils/workspace';
import { buildHashMap } from '../utils/hash';
import { publishPackage, PackageVersions, readPackageInfoFast, installForProject } from '../utils/npm';
import * as semver from 'semver';


type ExecuteBuildOptions = JsonObject & PublishOptions;
export default createBuilder<ExecuteBuildOptions>(executePublishCi);

export async function executePublishCi(_options: ExecuteBuildOptions, context: BuilderContext): Promise<BuilderOutput> {
  const workspace = getWorkspace();

  const projects = workspace.modules;

  context.logger.info('Calculating local hashes');

  const localHashMap = buildHashMap(projects);

  context.logger.info('Getting packages information from npm repository');

  const remotePackages = {} as PackageVersions;

  for (let i = 0; i < projects.length; i++) {
    const project = projects[i];
    remotePackages[project.name] = await readPackageInfoFast(project)
  }

  context.logger.info('Getting candidates for publish');
  const candidates = projects.filter(p => localHashMap[p.name] !== remotePackages[p.name].hash);

  context.logger.info(`Found ${candidates.length} packages to publish`);

  const wrapPackageJson = readPackageJson(workspace.packagesWrapper.root);

  context.logger.info('Following packages will be used from npm repository:');
  let dependencies = wrapPackageJson.dependencies as JsonObject;
  if(!dependencies) {
    dependencies = {};
    wrapPackageJson.dependencies = dependencies;
  }
  projects.filter(p => candidates.indexOf(p) === -1)
    .forEach(d => {
      const name = `@st/${d.name}`;
      dependencies[name] = remotePackages[d.name].version
      context.logger.info(`"${name}": "${dependencies[name]}"`);
    });

  savePackageJson(workspace.packagesWrapper.root, wrapPackageJson);

  context.logger.info('Installing unchanged packages');
  installForProject(workspace.packagesWrapper);

  const build = await context.scheduleBuilder('@st-devkit/build-package:build-ci', { projects: candidates.map(c => c.name)});
  const buildResult = await build.result;

  if (!buildResult.success) {
    throw new Error('Refuse to publish. Failed to build projects');
  }

  candidates.forEach(project => {
    context.logger.info(`Publishing ${project.root}`);

    if (!remotePackages[project.name]) {
      remotePackages[project.name].version = '0.0.0';
    }
    const newVersion = semver.inc(remotePackages[project.name].version, 'patch') as string;
    context.logger.info(`${project.name} version increment: ${remotePackages[project.name].version} -> ${newVersion}`);
    remotePackages[project.name].version = newVersion;

    const dist = getDistPath(project);

    const packageJson = readPackageJson(dist);
    packageJson.hash = localHashMap[project.name];
    packageJson.version = remotePackages[project.name].version;
    savePackageJson(dist, packageJson);

    publishPackage(dist);
  });

  return Promise.resolve({ success: true });
}
