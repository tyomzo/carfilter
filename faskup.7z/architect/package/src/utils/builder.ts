import { BuilderContext } from '@angular-devkit/architect';
import * as spawn from 'cross-spawn';

export function runBuild(project: string, context: BuilderContext): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const command = `ng`;
    const args = ['build', project]
    context.logger.info(`Executing '${command} ${args[0]} ${args[1]}'...`);
    const child = spawn(command, args);
    child.stderr.on('data', (data) => {
      const reason = data.toString().trim();
      if (reason !== '') {
        if (reason.toLowerCase().indexOf('warning:') !== -1) {
          context.logger.warn(`Warning: '${command} ${args[0]} ${args[1]}': "${reason}"`);
        } else {
          context.logger.error(`Failed '${command} ${args[0]} ${args[1]}': "${reason}"`);
          reject(reason);
        }
      }
    });
    child.on('close', code => {
      context.logger.info(`Completed '${command} ${args[0]} ${args[1]}'`);
      resolve(code === 0);
    });
  });
}


export class Semaphore {
  private current = 0;
  private running = [] as Promise<void>[];
  constructor(private max: number) { }

  async add(item: Promise<void>): Promise<void> {
    while (this.current >= this.max) {
      await Promise.race(this.running);
      this.current--;
    }
    this.running.push(item);
    this.current++;
  }

  waitAll(): Promise<void> {
    return Promise.all(this.running)
    .then(() => {
      this.current = 0;
      this.running = [];
    });
  }
}
