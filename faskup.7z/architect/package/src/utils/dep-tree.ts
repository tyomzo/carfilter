import { readDependencies, readPackageJson, Project } from './workspace';

export function getBuildOrder(projects: Project[]): DepNode[] {
  const dependencies = buildDepGraph(projects);
  let queue = [] as DepNode[];

  Object.keys(dependencies).forEach(key => {
    traverse(dependencies[key], queue);
    queue = queue.sort((a: DepNode, b: DepNode) => a.order - b.order);
  });

  return queue;
}

function traverse(node: DepNode, queue: DepNode[]): number {
  if (node.done) {
    return node.order;
  }

  if (node.started) {
    console.error(`Loop reference, started at: ${node.name}`);
    throw new Error(`Loop reference: ${node.name}`);
  }

  node.started = true;
  let maxOrder = 0;
  try {
    Object.keys(node.in).forEach(key => {
      const childOrder = traverse(node.in[key], queue);
      if (childOrder > maxOrder) {
        maxOrder = childOrder;
      }
    });
  } catch (e) {
    console.error(`Loop stack: -> ${node.name}`);
    throw (e);
  }

  queue.push(node);
  node.done = true;
  node.order = maxOrder + 1;
  return node.order;
}

function buildDepGraph(projects: Project[]): DepDictionary {
  const dependencies: DepDictionary = {};
  projects.forEach(p => {
    let node = dependencies[p.name];
    if (!node) {
      node = {
        name: p.name,
        in: {} as DepDictionary,
        inCount: 0,
        out: {} as DepDictionary,
        outCount: 0,
        done: false,
        started: false,
        order: 0
      } as DepNode;
      dependencies[p.name] = node;
    }

    readDependencies(readPackageJson(p.root))
      .filter(d => dependencyFilter(d))
      .map(d => normalizeName(d))
      .forEach(d => {
        let dep = dependencies[d];
        if (!dep) {
          dep = {
            name: d,
            in: {} as DepDictionary,
            inCount: 0,
            out: {} as DepDictionary,
            outCount: 0,
            done: false,
            started: false,
            order: 0
          } as DepNode;
          dependencies[d] = dep;
        }
        node.in[dep.name] = dep;
        node.inCount++;
        dep.out[node.name] = node;
        dep.outCount++;
      });
  });

  return dependencies;
}

function dependencyFilter(pkg: string): boolean {
  return pkg.startsWith('@st/');
}

function normalizeName(pkg: string): string {
  return pkg.replace('@st/', '');
}

type DepDictionary = { [key: string]: DepNode };

interface DepNode {
  name: string;
  in: DepDictionary;
  inCount: number;
  out: DepDictionary;
  outCount: number;
  done: boolean;
  started: boolean;
  order: number;
}
