import { JsonObject, parseJson } from '@angular-devkit/core';
import { getPackageDeps } from '@microsoft/package-deps-hash';
import { Project } from './workspace';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import * as crypto from 'crypto';

const hashMapPath = `./dist/hashmap.json`;

export function buildHashMap(projects: Project[]): HashMap {
  const hashMap = {} as HashMap;
  projects.forEach(p => hashMap[p.name] = getProjectHash(p));
  return hashMap;
}

export function getProjectHash(project: Project): string {
  const deps = getPackageDeps(project.root);
  const hash = crypto.createHash('sha256');

  Object.keys(deps.files).forEach(k => hash.update(deps.files[k]));

  return hash.digest('hex');
}

export function readDistHashMap(): HashMap {
  if (!existsSync(hashMapPath)) {
    return {};
  }
  const buffer = readFileSync(hashMapPath);
  const content = buffer.toString();
  const hashMap = parseJson(content) as JsonObject;
  const result = {} as HashMap;
  for (const key of Object.keys(hashMap)) {
    result[key] = hashMap[key] as string;
  }
  return result;
}

export function writeDistHashMap(hashMap: HashMap) {
  const json = JSON.stringify(hashMap, null, 2);
  writeFileSync(hashMapPath, json);
}

export interface HashMap {
  [project: string]: string;
}
