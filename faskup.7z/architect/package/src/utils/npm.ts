import { Executable } from '@microsoft/node-core-library';
import { JsonObject, parseJson } from '@angular-devkit/core';
import * as semver from 'semver';
import { Project } from './workspace';
import { default as got, Response as GotResponse } from 'got';

const artifactory = 'http://artifactory.danskenet.net/artifactory/api/npm/db-npm-Mobile_Pay_Support_Tool';

export function publishPackage(source: string) {
  const result = Executable.spawnSync('npm', ['publish', source]);
  if (result.status !== 0) {
    throw new Error(`"npm publish ${source}" failed: ${result.stderr}`);
  }
}

export function packPackage(source: string) {
  const result = Executable.spawnSync('npm', ['pack'], { currentWorkingDirectory: source });
  if (result.status !== 0) {
    throw new Error(`"npm pack ${source}" failed: ${result.stderr}`);
  }
}


export function readPackageInfo(project: Project): PackageVersion {
  const result = Executable.spawnSync('npm', ['view', `@st/${project.name}`, 'express', 'hash', 'version']);
  if (result.status !== 0) {
    const err = result.stderr;
    if (err.indexOf('npm ERR! 404') !== -1) {
      return {
        version: '0.0.0',
        hash: ''
      };
    }
    throw new Error(`npm view exited with status ${result.status}: ${result.stderr}`);
  }

  const stdout = result.stdout.trim();
  const lines = stdout.split('\n');
  const versionAndHashRegex = /(.+) = '(.+)'/;
  let version = '';
  let hash = '';

  lines.forEach(line => {
    const matches = versionAndHashRegex.exec(line);
    if (!!matches && matches.length === 3) {
      if (matches[1] === 'version') {
        version = matches[2];
      } else if (matches[1] === 'hash') {
        hash = matches[2];
      } else {
        throw new Error(`Unexpected response "npm view @st/${project.name} express hash version" output: "${line}"`);
      }
    } else if (semver.valid(line)) {
      version = line;
      hash = '';
    } else {
      throw new Error(`Cannot parse "npm view @st/${project.name} express hash version" output: "${line}"`);
    }
  });

  return {
    version,
    hash
  };
}

export function readPackageInfoFast(project: Project): Promise<PackageVersion> {
  return got(`${artifactory}/@st/${project.name}`)
    .then(response => parsePackageInfoResponse(response));
}

function parsePackageInfoResponse(response: GotResponse<string>) {
  const info = {
    version: '0.0.0',
    hash: ''
  };

  if(response.statusCode !== 200) {
    throw new Error(`Artifactorty response: ${response.statusCode}`);
  }

  const body = parseJson(response.body) as JsonObject;
  if(!body) {
    return info;
  }
  const distTags = body['dist-tags'] as JsonObject;
  if (!distTags) {
    return info;
  }
  const latestVersion = distTags['latest'] as string;
  if(!latestVersion) {
    return info;
  }
  const versions = body['versions'] as JsonObject;
  if(!versions) {
    return info;
  }
  const latest = versions[latestVersion] as JsonObject;
  if(!latest) {
    return info;
  }
  info.version = latest['version'] as string;
  info.hash = latest['hash'] as string;
  return info;
}

export function installForProject(project: Project) {
  const result = Executable.spawnSync('npm', ['install', project.root]);
  if (result.status !== 0) {
    throw new Error(`"npm install ${project.root}" failed: ${result.status}: ${result.stderr}`);
  }
}

export interface PackageVersions {
  [pkg: string]: PackageVersion;
}

export interface PackageVersion {
  version: string;
  hash?: string;
}
