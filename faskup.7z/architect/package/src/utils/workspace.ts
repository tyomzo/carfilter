import { JsonObject, parseJson } from '@angular-devkit/core';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import * as path from 'path';

export class ProjectsCollection {
  [key: string]: Project;
}

export class Workspace {
  projects: ProjectsCollection;
  constructor() {
    this.projects = new ProjectsCollection();
  }

  addProject(project: Project) {
    this.projects[project.name] = project;
  }

  allProjects(): Project[] {
    return Object.keys(this.projects).map(k => this.projects[k]);
  }

  get app(): Project {
    const app = this.allProjects().find(p => p.name === 'app');
    if(!app) {
      throw new Error('app project does not exist');
    }
    return app;
  }

  get modules() {
    return this.allProjects().filter(p => p.name !== 'app' && p.name !== 'packages')
  }

  get packagesWrapper() {
    const pkgs = this.allProjects().find(p => p.name === 'packages');
    if(!pkgs) {
      throw new Error('packages wrapper project does not exist');
    }
    return pkgs;
  }
}

export function getDistPath(project: Project) {
  const packagePath = `${project.root}/ng-package.json`;
  const buffer = readFileSync(packagePath);
  const content = buffer.toString();
  const data = parseJson(content) as JsonObject;
  const dist = data.dest as string;
  return dist.replace(/(?:\.\.\/)+/g, '');
}

export interface Project {
  name: string;
  root: string;
  sourceRoot: string;
}

export function getWorkspace(): Workspace {
  const currentDir = process.cwd();
  const configFilePath = findUp('angular.json', currentDir);
  if (configFilePath === null) {
    throw new Error('Failed to find angular.json');
  }

  const buffer = readFileSync(configFilePath);
  const configText = buffer === null ? '{}' : buffer.toString();
  const raw = parseJson(configText) as JsonObject;
  if (!raw) {
    throw new Error('Failed to read workspace');
  }
  const workspaceProjects = raw.projects as JsonObject;
  if (!workspaceProjects) {
    throw new Error('Workspace does not contains projects');
  }

  const workspace = new Workspace();

  for (const key of Object.keys(workspaceProjects)) {
    const project = workspaceProjects[key] as JsonObject;
    if (!project) {
      throw new Error('Failed to read project');
    }

    const root = project.root as string;
    if (!root) {
      throw new Error(`Failed to read root of project ${key}`);
    }

    const sourceRoot = project.sourceRoot as string;

    workspace.addProject({
      name: key,
      root,
      sourceRoot
    });
  }

  return workspace;
}

export function readProject(projectName: string): Project {
  const workspace = getWorkspace();
  return workspace.projects[projectName];
}

export function readPackageJson(path: string): JsonObject {
  const fullPath = `${path}/package.json`;
  const buffer = readFileSync(fullPath);
  const content = buffer.toString();
  return parseJson(content) as JsonObject;
}

export function savePackageJson(path: string, packageJson: JsonObject) {
  const fullPath = `${path}/package.json`;
  const content = JSON.stringify(packageJson, null, 2);
  writeFileSync(fullPath, content);
}

export function readDependencies(packageJson: JsonObject ) {
  const allDependencies: string[] = [];
  const deps = packageJson.dependencies as JsonObject;
  if(deps) {
    for (const key of Object.keys(deps)) {
      allDependencies.push(key);
    }
  }
  const peerDeps = packageJson.peerDependencies as JsonObject;
  if(peerDeps) {
    for (const key of Object.keys(peerDeps)) {
      allDependencies.push(key);
    }
  }
  return allDependencies;
}

function findUp(name: string, from: string) {
  const root = path.parse(from).root;

  let currentDir = from;
  while (currentDir && currentDir !== root) {
    const p = path.join(currentDir, name);
    if (existsSync(p)) {
      return p;
    }
    currentDir = path.dirname(currentDir);
  }

  return null;
}
