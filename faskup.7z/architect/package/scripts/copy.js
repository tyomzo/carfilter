async function copy() {
  const fs = require('fs-extra');
  const srcRoot = './';
  const distRoot = '../../dist/architect/build-package';
  const builders = 'builders.json';
  const schema = 'schema.json';
  const package = 'package.json';

  async function copyBuildDefinition() {

    if (!(await fs.exists(`${builders}`))) {
      throw new Error(`${builders} was not found`);
    }
    await fs.copy(`${builders}`, `${distRoot}/${builders}`);
  }

  async function copyPackageJson() {

    if (!(await fs.exists(`${package}`))) {
      throw new Error(`${package} was not found`);
    }
    await fs.copy(`${package}`, `${distRoot}/${package}`);
  }

  async function copySchemas(folder) {
    const folders = await fs.readdir(folder);
    for (let i = 0; i < folders.length; i++) {
      const path = folders[i];
      const stats = await fs.stat(`${folder}/${path}`);
      if (stats.isDirectory()) {
        copySchemas
          (`${folder}/${path}`);
      } else if (stats.isFile() && isSchema(path)) {
        await copyToDist(folder, path);
      }
    }
  }

  async function copyToDist(folder, path) {
    const dist = `${folder.replace(srcRoot, distRoot)}`;
    await fs.ensureDir(dist);
    await fs.copyFile(`${folder}/${path}`, `${dist}/${path}`);
  }

  function isSchema(path) {
    return path === schema;
  }

  await copyBuildDefinition();
  await copySchemas(srcRoot);
  await copyPackageJson();

};

copy();
